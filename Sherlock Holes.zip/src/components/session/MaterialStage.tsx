import { FileText, ListPlus, Plus, Upload, X } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";

import { SherlockFace } from "@/components/SherlockFace";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

const DURATIONS = [60, 120, 180, 240, 300];

export function MaterialStage({
  initialNotes,
  initialConcepts,
  initialLimit,
  busy,
  onStart,
}: {
  initialNotes: string;
  initialConcepts: string[];
  initialLimit: number;
  busy: boolean;
  onStart: (payload: { notes: string; concepts: string[]; limit: number }) => void;
}) {
  const [notes, setNotes] = useState(initialNotes);
  const [concepts, setConcepts] = useState<string[]>(initialConcepts);
  const [draft, setDraft] = useState("");
  const [limit, setLimit] = useState(initialLimit || 180);
  const fileInput = useRef<HTMLInputElement>(null);

  const addConcept = () => {
    const value = draft.trim();
    if (!value) return;
    setConcepts((current) => [...current, value]);
    setDraft("");
  };

  const readFile = async (file: File) => {
    if (file.size > 400_000) {
      toast.error("That file is a bit long — paste the section you want to teach instead.");
      return;
    }
    const text = await file.text();
    setNotes((current) => (current ? `${current}\n\n${text}` : text));
    toast.success(`Added notes from ${file.name}`);
  };

  const ready = notes.trim().length > 20 || concepts.length > 0;

  return (
    <div className="mx-auto grid w-full max-w-5xl gap-8 px-5 py-8 lg:grid-cols-[1fr_320px]">
      <div className="animate-rise-in">
        <h2 className="text-2xl font-semibold">Give Sherlock the case file</h2>
        <p className="mt-1 text-muted-foreground">
          He knows nothing about this topic. Hand him your notes, or just list what you plan to
          cover — he'll use it to spot what you leave out.
        </p>

        <Tabs defaultValue="notes" className="mt-6">
          <TabsList>
            <TabsTrigger value="notes">
              <FileText className="mr-2 h-4 w-4" /> Notes
            </TabsTrigger>
            <TabsTrigger value="concepts">
              <ListPlus className="mr-2 h-4 w-4" /> Key concepts
            </TabsTrigger>
          </TabsList>

          <TabsContent value="notes" className="space-y-3">
            <Textarea
              value={notes}
              onChange={(event) => setNotes(event.target.value)}
              placeholder="Paste your lecture notes, textbook section or summary here…"
              className="min-h-56"
            />
            <input
              ref={fileInput}
              type="file"
              accept=".txt,.md,.csv,.json,text/plain"
              className="hidden"
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (file) void readFile(file);
                event.target.value = "";
              }}
            />
            <Button variant="secondary" onClick={() => fileInput.current?.click()}>
              <Upload className="mr-2 h-4 w-4" /> Upload a text file
            </Button>
          </TabsContent>

          <TabsContent value="concepts" className="space-y-3">
            <div className="flex gap-2">
              <Input
                value={draft}
                placeholder="e.g. Carbocation stability"
                onChange={(event) => setDraft(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter") {
                    event.preventDefault();
                    addConcept();
                  }
                }}
              />
              <Button onClick={addConcept} disabled={!draft.trim()}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            {concepts.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                Add each concept you intend to explain. Sherlock will check them off as you go.
              </p>
            ) : (
              <ul className="flex flex-wrap gap-2">
                {concepts.map((concept, index) => (
                  <li
                    key={`${concept}-${index}`}
                    className="flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-sm"
                  >
                    {concept}
                    <button
                      type="button"
                      aria-label={`Remove ${concept}`}
                      onClick={() => setConcepts((current) => current.filter((_, i) => i !== index))}
                      className="text-muted-foreground hover:text-destructive"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </TabsContent>
        </Tabs>

        <div className="mt-8">
          <Label className="label-caps">How long will you speak?</Label>
          <div className="mt-3 flex flex-wrap gap-2">
            {DURATIONS.map((seconds) => (
              <Button
                key={seconds}
                variant={limit === seconds ? "default" : "secondary"}
                onClick={() => setLimit(seconds)}
              >
                {seconds / 60} min
              </Button>
            ))}
          </div>
        </div>

        <Button
          size="lg"
          className="mt-8"
          disabled={!ready || busy}
          onClick={() => onStart({ notes: notes.trim(), concepts, limit })}
        >
          {busy ? "Sherlock is reading…" : "Teach Sherlock!"}
        </Button>
        {!ready && (
          <p className="mt-2 text-sm text-muted-foreground">
            Add some notes or at least one concept first.
          </p>
        )}
      </div>

      <aside className="case-file flex flex-col items-center justify-center p-6">
        <SherlockFace verdict="neutral" size="md" />
        <p className="mt-4 text-center text-sm text-muted-foreground">
          “I've read nothing on this. Explain it to me as though I'm brand new — because I am.”
        </p>
      </aside>
    </div>
  );
}
